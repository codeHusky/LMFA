$.getScript("http://terminalbit.com/agario/launcher.js")
$.getScript(chrome.extension.getURL('injectScript.js'));